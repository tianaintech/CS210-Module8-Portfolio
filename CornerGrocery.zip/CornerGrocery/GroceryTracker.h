#ifndef GROCERY_TRACKER_H
#define GROCERY_TRACKER_H

#include <iostream>
#include <fstream>
#include <map>
#include <string>

class GroceryTracker {
private:
    std::map<std::string, int> itemFrequency;  // Map to store item names and their frequencies
    std::string inputFile = "CS210_Project_Three_Input_File.txt";  // Input file name
    std::string backupFile = "frequency.dat";  // Backup file name

public:
    // Method to read the input file and count the frequencies of items
    void readFileAndCountFrequencies();

    // Method to get the frequency of a specific item
    int getItemFrequency(const std::string& item);

    // Method to print the frequencies of all items
    void printAllFrequencies();

    // Method to print the histogram
    void printHistogram();

    // Method to write the frequencies to a backup file
    void writeToBackupFile();
};

#endif // GROCERY_TRACKER_H


