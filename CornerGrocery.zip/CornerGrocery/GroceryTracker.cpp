#include "GroceryTracker.h"

// Method to read the input file and count the frequencies of items
void GroceryTracker::readFileAndCountFrequencies() {
    std::ifstream file(inputFile);
    std::string item;

    if (!file.is_open()) {
        std::cerr << "Error opening file " << inputFile << std::endl;
        return;
    }

    // Read each line (item) from the file and update its frequency
    while (std::getline(file, item)) {
        itemFrequency[item]++;  // Increment the count for the item
    }

    file.close();
}

// Method to get the frequency of a specific item
int GroceryTracker::getItemFrequency(const std::string& item) {
    if (itemFrequency.find(item) != itemFrequency.end()) {
        return itemFrequency[item];
    }
    else {
        return 0;  // If item is not found, return 0
    }
}

// Method to print the frequencies of all items
void GroceryTracker::printAllFrequencies() {
    for (const auto& entry : itemFrequency) {
        std::cout << entry.first << " " << entry.second << std::endl;
    }
}

// Method to print the histogram
void GroceryTracker::printHistogram() {
    for (const auto& entry : itemFrequency) {
        std::cout << entry.first << " ";
        for (int i = 0; i < entry.second; ++i) {
            std::cout << "*";
        }
        std::cout << std::endl;
    }
}

// Method to write the frequencies to a backup file
void GroceryTracker::writeToBackupFile() {
    std::ofstream file(backupFile);

    if (!file.is_open()) {
        std::cerr << "Error opening file " << backupFile << std::endl;
        return;
    }

    for (const auto& entry : itemFrequency) {
        file << entry.first << " " << entry.second << std::endl;
    }

    file.close();
}

