#include <iostream>
#include <string>
#include "GroceryTracker.h"

int main() {
    // Create an instance of GroceryTracker
    GroceryTracker tracker;

    // Step 1: Read the input file and count frequencies
    tracker.readFileAndCountFrequencies();

    // Step 2: Write frequencies to backup file
    tracker.writeToBackupFile();

    // Variable to store the user's choice
    int choice = 0;
    std::string item;

    // Display menu until the user chooses to exit
    do {
        std::cout << "\nMenu Options:\n";
        std::cout << "1. Look up the frequency of an item\n";
        std::cout << "2. Print all items and their frequencies\n";
        std::cout << "3. Print histogram of item frequencies\n";
        std::cout << "4. Exit\n";
        std::cout << "Enter your choice: ";
        std::cin >> choice;
        std::cin.ignore();  // Ignore the newline character left by std::cin

        switch (choice) {
        case 1:
            std::cout << "Enter the item to search for: ";
            std::getline(std::cin, item);
            std::cout << "The frequency of " << item << " is: "
                << tracker.getItemFrequency(item) << std::endl;
            break;

        case 2:
            std::cout << "Items and their frequencies:\n";
            tracker.printAllFrequencies();
            break;

        case 3:
            std::cout << "Histogram of item frequencies:\n";
            tracker.printHistogram();
            break;

        case 4:
            std::cout << "Exiting the program.\n";
            break;

        default:
            std::cout << "Invalid choice. Please try again.\n";
        }

    } while (choice != 4);  // Continue until the user chooses to exit

    return 0;
}
